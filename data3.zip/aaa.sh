for k in 3 5
do
for j in 2 3 4 5 6 7
do
make
make run
make clean
mv Cell.cpp Cellc.txt;
let ja=$j+1
let jb=2**$j
let jc=2**$ja
sed -i 's/'maxNumLevelLTP=$jb'/'maxNumLevelLTP=$jc'/' Cellc.txt;
sed -i 's/'maxNumLevelLTD=$jb'/'maxNumLevelLTD=$jc'/' Cellc.txt;
mv Cellc.txt Cell.cpp;
done
# reset-up maxnumLTP
mv Cell.cpp Cellc.txt;
sed -i 's/'maxNumLevelLTP=256'/'maxNumLevelLTP=4'/' Cellc.txt;
sed -i 's/'maxNumLevelLTD=256'/'maxNumLevelLTD=4'/' Cellc.txt;
mv Cellc.txt Cell.cpp;

mv Cell.cpp Cellc.txt;

let ka=$k+2
sed -i 's/'NL_LTP=$k'/'NL_LTP=$ka'/' Cellc.txt;
sed -i 's/'NL_LTD=$k'/'NL_LTD=$ka'/' Cellc.txt;

mv Cellc.txt Cell.cpp;
done


